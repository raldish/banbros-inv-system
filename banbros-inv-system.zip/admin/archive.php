<?php
    include "connection.php";

    $id = $_GET['archive'];

    // Retrieve the data to be archived from the database
    $query = "SELECT * FROM client WHERE ID = '$id'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    // Check if the data exists
    if ($row) {
        // Insert the data into the archive table
$query = "INSERT INTO tbl_archive (ID, company_code, assigned_to, firstname, middlename, surname, location_n, model_description, serial_number, quantity, con_dition, added_at, deleted_at) 
VALUES ('$row[ID]', '$row[company_code]', '$row[assigned_to]', '$row[firstname]', '$row[middlename]', '$row[surname]', '$row[location_n]', '$row[model_description]', '$row[serial_number]', '$row[quantity]', '$row[con_dition]', '$row[added_at]', DATE_ADD(NOW(), INTERVAL 3 DAY))";

// Execute the query
if (mysqli_query($conn, $query)) {
// Delete the data from the original table
$query = "DELETE FROM client WHERE ID = '$id'";
if (mysqli_query($conn, $query)) {
$_SESSION['success'] = "Record has been archived successfully";
} else {
$_SESSION['error'] = "Error archiving data: " . mysqli_error($conn);
}
} else {
$_SESSION['error'] = "Error inserting data into archive table: " . mysqli_error($conn);
}
    } else {
        $_SESSION['error'] = "Data not found.";
    }

    header("location: index.php");
?>